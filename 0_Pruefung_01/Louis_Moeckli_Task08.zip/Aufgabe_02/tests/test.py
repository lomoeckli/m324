import unittest
from src.number import *

class TestEven(unittest.TestCase):
    def test_equal(self):
        self.assertTrue(is_even(10))
    
    def test_not_equal(self):
        self.assertFalse(is_even(11))
            